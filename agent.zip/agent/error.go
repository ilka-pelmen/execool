// api_errors.go
package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type apiError struct {
	Status  int    `json:"status"`
	Code    string `json:"code"`
	Message string `json:"message"`
}

func (e *apiError) Error() string { return e.Message }

func newAPIError(status int, code, format string, args ...any) *apiError {
	return &apiError{
		Status:  status,
		Code:    code,
		Message: fmt.Sprintf(format, args...),
	}
}

func writeAPIError(w http.ResponseWriter, err *apiError) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(err.Status)
	_ = json.NewEncoder(w).Encode(err)
}

func invalidPath(format string, args ...any) *apiError {
	return newAPIError(400, "invalid_path", format, args...)
}
