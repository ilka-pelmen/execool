package main

import (
	"encoding/json"
	"io"
	"net/http"
)

type WebHandler struct {
	Config      *Config
	Manager     *SessionManager
	UsedTickets *usedTickets
}

type createSessionRequest struct {
	ID       string `json:"id"`
	Language string `json:"language"`
}

func NewWebHandler(config *Config, session_manager *SessionManager, mux *http.ServeMux) {
	h := WebHandler{Config: config, Manager: session_manager}
	mux.Handle("POST /internal/sessions", h.auth(http.HandlerFunc(h.CreateSession)))
	mux.Handle("DELETE /internal/sessions/{id}", h.auth(http.HandlerFunc(h.DeleteSession)))
	mux.Handle("GET /internal/status", h.auth(http.HandlerFunc(h.Status)))
}

// Private
func (h *WebHandler) auth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !verifyAgentAPIKey(h.Config.APIKey, r.Header.Get("Authorization")) {
			writeAPIError(w, newAPIError(
				http.StatusUnauthorized,
				"unauthorized",
				"Invalid agent API key",
			))
			return
		}

		next.ServeHTTP(w, r)
	})
}

// POST /internal/sessions {id, language}
func (wh *WebHandler) CreateSession(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)

	var req createSessionRequest
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()

	if err := dec.Decode(&req); err != nil {
		writeAPIError(w, newAPIError(
			http.StatusBadRequest, "invalid_request", "Invalid request body",
		))
		return
	}

	// Не принимать несколько JSON-объектов в одном теле.
	if err := dec.Decode(&struct{}{}); err != io.EOF {
		writeAPIError(w, newAPIError(
			http.StatusBadRequest, "invalid_request", "Unexpected data after request",
		))
		return
	}

	session, err := wh.Manager.Create(req.ID, req.Language)
	if err != nil {
		writeAPIError(w, newAPIError(
			http.StatusBadRequest, "session_create_failed", "Could not create session",
		))
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)

	_ = json.NewEncoder(w).Encode(map[string]string{
		"id":       session.ID,
		"language": session.Language,
	})
}

func (wh *WebHandler) DeleteSession(w http.ResponseWriter, r *http.Request) {
	wh.Manager.Delete(r.PathValue("id"))
	w.WriteHeader(http.StatusNoContent)
}

func (wh *WebHandler) Status(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
}
